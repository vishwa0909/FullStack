module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "sai@123",
  DB: "testdb",
};
